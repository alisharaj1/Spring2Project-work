import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { addairportComponent } from './addairport.component';

describe('AddairportComponent', () => {
  let component: addairportComponent;
  let fixture: ComponentFixture<addairportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ addairportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(addairportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

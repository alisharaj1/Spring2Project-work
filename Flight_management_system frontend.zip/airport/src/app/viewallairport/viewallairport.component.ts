import { Component, OnInit } from '@angular/core';
import { AirportService } from '../airport.service';
import { Airport } from '../airport';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewallairport',
  templateUrl: './viewallairport.component.html',
  styleUrls: ['./viewallairport.component.css']
})
export class ViewallairportComponent implements OnInit {
  airports: Airport[] = [];
  messege: string;
  airport: Airport = new Airport();
  deletemessege = false;
  constructor(private airportservice: AirportService, private route: Router) {}

  ngOnInit() {
this.airportservice.viewallairport().subscribe(data => this.airports = data);
console.log(this.airports);
  }

}

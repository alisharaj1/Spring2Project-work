import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Airport } from './airport';



@Injectable({
  providedIn: 'root'
})
export class AirportService {

  constructor(private http: HttpClient) { }
  public addairport(airport: Airport): Observable<any>{
      return this.http.post( 'http://localhost:8098/addairport' , airport, {responseType: 'text'});
    }
    public viewallairport(): Observable<any>{
      return this.http.get('http://localhost:8098/viewallairport');
    }
    public updateairport(airport: Airport): Observable<any>{
      return this.http.put(`http://localhost:8098/updateairport/${airport.airportCode}`, airport, {responseType: 'text'});
    }
    public deleteairport(airportCode: string): Observable<any>
    {
      console.log('inside delete service' + airportCode);
      return this.http.delete(`http://localhost:8098/deleteairport/${airportCode}`, {responseType: 'text'});
    }
  public airportdetails(airportCode: string): Observable<any>{
    return this.http.get(`http://localhost:8098/airportdetails/${airportCode}`, {responseType: 'text'});
  }}

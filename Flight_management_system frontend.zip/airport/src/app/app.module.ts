import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http' ;
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { addairportComponent } from './addairport/addairport.component';
import { FormsModule } from '@angular/forms';
import { ViewallairportComponent } from './viewallairport/viewallairport.component';

import { HomeComponent } from './home/home.component';
import { UpdateairportComponent } from './updateairport/updateairport.component';
import { DeleteairportComponent } from './deleteairport/deleteairport.component';
import { AirportdetailsComponent } from './airportdetails/airportdetails.component';

@NgModule({
  declarations: [
    AppComponent,
    addairportComponent,
    ViewallairportComponent,
   UpdateairportComponent,
    HomeComponent,
    DeleteairportComponent,
    AirportdetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

export class Airport {
    airportCode: string;
    airportName: string;
    airportLocation: string;
}

import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { addairportComponent } from './addairport/addairport.component';
import { ViewallairportComponent } from './viewallairport/viewallairport.component';
import { HomeComponent } from './home/home.component';
import { UpdateairportComponent } from './updateairport/updateairport.component';
import { DeleteairportComponent } from './deleteairport/deleteairport.component';
import { AirportdetailsComponent } from './airportdetails/airportdetails.component';

const routes: Routes = [
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: 'home', component: HomeComponent},
  {path: 'airportdetails', component: AirportdetailsComponent},
  {path: 'deleteairport', component: DeleteairportComponent},
  {path: 'addairport', component: addairportComponent},
  {path: 'viewallairport', component: ViewallairportComponent},
  {path: 'updateairport', component: UpdateairportComponent}

];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

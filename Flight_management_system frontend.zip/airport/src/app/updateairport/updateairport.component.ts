import { Component, OnInit } from '@angular/core';
import { Airport } from '../airport';
import { AirportService } from '../airport.service';

@Component({
  selector: 'app-updateairport',
  templateUrl: './updateairport.component.html',
  styleUrls: ['./updateairport.component.css']
})
export class UpdateairportComponent  implements OnInit {
  airport: Airport = new Airport();
messege: string;
errormessege: string;
  constructor(private airportservice: AirportService) { }

  ngOnInit(): void {
  }
  updateairport(){
    this.airportservice.updateairport(this.airport).subscribe((data) => {
      console.log('data', data);
      this.messege = data;
      this.errormessege = undefined;
      this.airport = new Airport(); },
      error => {'Invalid Airport Code'});
    }

  }


